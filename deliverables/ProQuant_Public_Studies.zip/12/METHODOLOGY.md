# 12 · AI-assisted Quantitative Research

**Status:** Completed deterministic, source-linked research demonstrator using official SEC annual facts; no AI-generated claim is presented as verified fact.

**Summary:** {
  "evidence_rows": 3,
  "issuer_coverage": [
    "AAPL",
    "MSFT",
    "NVDA"
  ],
  "method": "XBRL extraction, filed-date preservation, calculations, evidence ledger; no LLM generation"
}

**Method:** Generate a concise issuer evidence ledger from extracted annual SEC facts, retaining ticker, fiscal year, filed date and source endpoint. AI is not called; the demonstrator verifies the no-AI manual fallback and citation structure.

**Source:** https://www.sec.gov/edgar/sec-api-documentation

**Limitations:**
- This demonstrates the evidence workflow; it is not independent investment research or advice.
- No external model or AI API was used.
- Statements are limited to the fields and periods explicitly recorded.
